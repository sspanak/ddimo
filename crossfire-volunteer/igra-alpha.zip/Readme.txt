Crossfire Volunteer
===========================
2007-2008, 2014 - Dimo Karaivanov
email: de.karaivanov@gmail.com

---------------------------
TABLE OF CONTENTS:

1. About the game
2. System Requirements
3. Troubleshooting
---------------------------

1. About the game
===========================
Crossfire Volunteer is meant to be a simple game with spaceships in 64kb in which evil aliens in colorful ships try to conquer the known part of the Universe. You are the chosen one, who pilots a green ship with red wings and who tries to stop the evil hordes by killin' 'em all. The destroyed ships drop shield and weapon batteries, which can be used against them.

The game is inspired from old Nintendo classics, from the 1980s, such as Battle City and Galaxian.

2. System Requirements
===========================
Minimal requirements:

Celeron 500 Mhz
32 MB RAM
2 MB Video card with OpenGL support - ATi Rage Pro or similar
300 kb free disk space
Windows XP (2000 might work, but it has never been tested)

Recommended requirements:
Pentium or Athlon 1 GHz
64 MB RAM
32 MB Video Card with OpenGL support - GeForce 2 or similar
A Sound Card that supports MIDI playback
300 kb free disk space
Windows XP or newer

3. Troubleshooting
===========================
- If you experience stuttering or lagging while playing the game, you can try the following actions, to improve it:
1) Close any unused programs, antivirus software, computer and memory optimizers.
2) Try playing in full screen. Usually, the game will run much smoother in full screen mode, than in window, at given resolution.
3) You can make the game use your computer's resources economicaly or not, by pressing F9 (default is "yes"). Turn off that function and it will give you some performance advantage.
4) And if you tried everything, but it still runs poorly, maybe it is time for an upgrade.

- Old video cards with little amount of memory and poor OpenGL support might experience trouble when switching between full screen display modes. If you do not see the entire game scene or if it does not fill the entire screen, close it and start it again. If this does not help, you will first have to set your preferred resolution using windows, then start the game.

- New computers with Pentium IV or AthlonXP are fast enough to run the game smoothly even if you use only 10-15% of their horse power. This means it is recommended to keep the economical processor usage turned on. This way you can save power or run other tasks in the background.

- If you hear strange humming or buzzing during gameplay... well I don't know why is that.